// AirgeadBankingApp.h
#ifndef AIRGEAD_BANKING_APP_H_
#define AIRGEAD_BANKING_APP_H_

class AirgeadBankingApp {
public:
    AirgeadBankingApp(double t_initialInvestment, double t_monthlyDeposit, double t_annualInterest, int t_numYears);

    void displayInputSummary() const;
    void displayReportWithoutMonthlyDeposits() const;
    void displayReportWithMonthlyDeposits() const;

private:
    double m_initialInvestment;
    double m_monthlyDeposit;
    double m_annualInterest;
    int m_numYears;
};

#endif // AIRGEAD_BANKING_APP_H_


