#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>
using namespace std;

class GroceryTracker {
private:
    map<string, int> itemFrequency;

public:
    // Constructor loads input file and builds frequency map
    GroceryTracker(const string& inputFile) {
        ifstream inFile(inputFile);
        string item;
        while (inFile >> item) {
            itemFrequency[item]++;
        }
        inFile.close();
        SaveToFile("frequency.dat");
    }

    void SaveToFile(const string& outFile) {
        ofstream out(outFile);
        for (const auto& pair : itemFrequency) {
            out << pair.first << " " << pair.second << endl;
        }
        out.close();
    }

    void FindFrequency(const string& item) const {
        auto it = itemFrequency.find(item);
        if (it != itemFrequency.end()) {
            cout << item << " was purchased " << it->second << " time(s)." << endl;
        }
        else {
            cout << item << " was not purchased today." << endl;
        }
    }

    void PrintFrequencies() const {
        cout << "\nITEM PURCHASE FREQUENCIES\n";
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void PrintHistogram() const {
        cout << "\nPURCHASE HISTOGRAM\n";
        for (const auto& pair : itemFrequency) {
            cout << setw(15) << left << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }
};

void DisplayMenu() {
    cout << "\n==== Corner Grocer Menu ====\n";
    cout << "1. Search for item frequency\n";
    cout << "2. Print frequency of all items\n";
    cout << "3. Display histogram of purchases\n";
    cout << "4. Exit\n";
    cout << "Enter your choice (1-4): ";
}

int main() {
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt");

    int choice;
    string searchItem;

    while (true) {
        DisplayMenu();
        cin >> choice;
        cin.ignore(); // Flush newline from buffer

        switch (choice) {
        case 1:
            cout << "Enter item to search: ";
            getline(cin, searchItem);
            tracker.FindFrequency(searchItem);
            break;
        case 2:
            tracker.PrintFrequencies();
            break;
        case 3:
            tracker.PrintHistogram();
            break;
        case 4:
            cout << "Exiting program. Goodbye!" << endl;
            return 0;
        default:
            cout << "Invalid choice. Please enter a number 1�4.\n";
        }
    }

    return 0;
}